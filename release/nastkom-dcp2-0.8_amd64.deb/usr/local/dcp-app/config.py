WTF_CSRF_ENABLE = True
WTF_CSRF_SECRET_KEY = 'you-will-never-quess'
