#! /bin/bash

#if [ $# -ne 1 ];
#    then echo "illegal number of parameters"
#    exit -2
#fi

output=$(qmicli -d /dev/cdc-wdm0  --wds-get-packet-service-status  | awk -F[:] '{print $2}')

if [ "${output}" = " 'connected'" ]; then
	echo "WDS CONNECTED"

#	ping -c1 -I "$1" 8.8.8.8
	ping -c1 -I wwan0 8.8.8.8

	if [ "$?" != 0 ]; then
#        	ping -c1 -I "$1" 8.8.8.8
        	ping -c1 -I wwan0 8.8.8.8
        	if [ "$?" != 0 ]; then
                	echo "PING FAILED"
                	exit -1
        	fi
	fi
	exit 0
fi
echo "WDS NOT CONNECTED"
exit -1
