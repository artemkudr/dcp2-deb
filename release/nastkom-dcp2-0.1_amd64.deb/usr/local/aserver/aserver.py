#!/usr/bin/python3
import shutil
import socket
import selectors
import types
import traceback
import libserver
import json


#def_host = "77.242.3.226"
#def_port = 87

###             ###
###     MAIN    ###
###             ###

def errorExit():
	shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
	time.sleep(5)
	exit()

conf_file = "/usr/share/dcp-conf/dcp.conf"
try:
	with open(conf_file, "r") as json_file:
		conf = json.load(json_file)
		if "local_ip" not in conf  or "local_port" not in conf:
			print("ServerIP or serverPort not set")
			errorExit()

		HOST = conf["local_ip"]
		PORT = int(conf["local_port"])
		if len(HOST) < 3 or PORT < 80 or PORT  > 65535:
			print("ServerIP or serverPort are bad")
			errorExit()
			#HOST = def_host
			#PORT = def_port
except Exception:
	print("dcp.conf file Error")
	errorExit()
	#HOST = def_host
	#PORT = def_port

sel = selectors.DefaultSelector()
lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Avoid bind() exception: OSError: [Errno 48] Address already in use
lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

lsock.bind((HOST,PORT))
lsock.listen()
print('aserver listening on ', (HOST,PORT))
lsock.setblocking(False)
sel.register(lsock, selectors.EVENT_READ, data=None)


def accept_wrapper(sock):
	conn, addr = sock.accept()
	print('aserver accepted connection from ', addr)
	conn.setblocking(False)
	message = libserver.Message(sel, conn, addr)
	sel.register(conn, selectors.EVENT_READ, data=message)

while True:
	events = sel.select(timeout=None)
	for key, mask in events:
		if key.data is None:
			accept_wrapper(key.fileobj)
		else:
			message = key.data
			try:
				message.process_events(mask)
			except Exception:
				print('aserver main: error: exception for', f'{message.addr}\n{traceback.format_exc()}')
				message.close()


