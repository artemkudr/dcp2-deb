import sys
import selectors
import io
import struct
import binascii
import logging

from logging.handlers import RotatingFileHandler
from datetime import datetime

#MAX_LOG_BYTES = 2048
MAX_LOG_BYTES = 8000000

class Message:
	def __init__(self, selector, sock, addr):
		self.selector = selector
		self.sock = sock
		self.addr = addr
		self._recv_buffer = b""
		self._send_buffer = b""
		self.request = None
		self.response_created = False
		self.parcel_num = 0
		self.package_len = 0
		self.content_type = 0
#		self.file = None
		self.imei = ""
		self.handler =  None


	def _set_selector_events_mask(self, mode):
		"""Set selector to listen for events : mode is 'r', 'w' or 'rw'."""
		if mode == "r":
			events = selectors.EVENT_READ
		elif mode == "w":
#			print("selectors w")
			events = selectors.EVENT_WRITE
		elif mode == "rw":
			events = selectors.EVENT_READ | selectors.EVENT_WRITE
		else:
			raise ValueError(f"Invalid events mask mode {repr(mode)}.")
		self.selector.modify(self.sock, events, data = self)


	def _read(self):
		try:
			data = self.sock.recv(4096)
		except BlockingIOError:
			# Resource temporarily unawailable (errno EWOULDBLOCK)
			pass
		else:
			if data:
				self._recv_buffer += data
			else:
				raise RuntimeError("Peer ", self.addr, " closed")

	def _write(self):
		if self._send_buffer:
			print("sending ", repr(self._send_buffer), " to ", self.addr)
			try:
				sent = self.sock.send(self._send_buffer)
			except BlockingIOError:
				pass
			else:
				self._init_recv_process()
				self._set_selector_events_mask("r")

	def _init_recv_process(self):
		self.package_len = 0
		self.parcel_num = 0
		self.content_type = 0

	def process_events(self, mask):
		if mask & selectors.EVENT_READ:
			self.read();
		if mask & selectors.EVENT_WRITE:
			self.write();

#	def answer_crc_calc(self, data, len):
#		crc = 0
#		while len:
#			crc=crc+data
#

	def process_header(self):
#		print("header received")
		utc = datetime.utcnow()
		timestamp = int(utc.timestamp())
#		utc_time = int(datetime.utcnow().timestamp())
		self.imei = str(struct.unpack('<Q',self._recv_buffer[2:10])[0])

#		self.file = open('./data/'+self.imei, 'a')
#		self.file = open('./data/'+self.imei+'_'+str(utc_time), 'a')
#		self.file = open('./data/'+self.imei+'_'+utc.strftime("%y%m%d_%H%M%S"), 'a')
#		self.file.write('header:'+ self._recv_buffer[:10].hex()+"\r\n")

		self.logger = logging.getLogger(self.imei)
		self.logger.setLevel(logging.INFO)

		open('/usr/local/data/'+self.imei, 'a').close()
		self.handler = RotatingFileHandler('/usr/local/data/'+self.imei, maxBytes = MAX_LOG_BYTES, backupCount=1) 
		self.logger.addHandler(self.handler)

		self._recv_buffer = self._recv_buffer[10:]
		answer = bytearray()
		answer.extend(b'\x7B')
		answer.extend(b'\x00') # or 04 it time presence
		answer.extend(b'\x00')

		# send time in aswer
#		answer.extend(int(timestamp).to_bytes(4,'little'))
#		answer.insert(3,(sum(answer[3:6])//256).to_bytes(1,"little")[0])

		answer.extend(b'\x7D')
		self._send_buffer += answer
		# Set selector to listen for write events, we're done reading.
		self._set_selector_events_mask("w")

	def process_package(self):
#		print("package received")
		if self.package_len == 0 and len(self._recv_buffer) >= 2:
			self.parcel_num = self._recv_buffer[1]
			self.package_len = 2
		if len(self._recv_buffer) > self.package_len:
			self.content_type = self._recv_buffer[self.package_len]
#			print("content_type ", self.content_type)
			if self.content_type == 0x5D:
				# standart print
				# over logging mechanism
				self.logger.info("data:" + self._recv_buffer[:self.package_len+1].hex())
				self._recv_buffer = self._recv_buffer[self.package_len+1:]

				answer = bytearray()
				answer.extend(b'\x7B')
				answer.extend(b'\x00')
				answer.extend(int(self.parcel_num).to_bytes(1,"little"))
				answer.extend(b'\x7D')
				self._send_buffer = answer
				self._set_selector_events_mask("w")
			elif self.content_type == 0x01 or self.content_type == 0x06 or self.content_type == 0x03 or self.content_type == 0x04 :
				if len(self._recv_buffer) > (self.package_len+2):
					self.package_len += struct.unpack('<H',self._recv_buffer[self.package_len+1 : self.package_len+3])[0] + 8
#					print("package_len ", self.package_len)
					if len(self._recv_buffer) > self.package_len:
						self.process_package()
			else:
				self.close()

	def read(self):
		self._read()

		if len(self._recv_buffer) >= 10:
			if self._recv_buffer[0] == 0xFF and self._recv_buffer[1] == 0x25:
				self.process_header()
			elif self._recv_buffer[0] == 0x5B:
				self.process_package()
			else:
				#self._recv_buffer = []
				# print(self._recv_buffer[:10].hex())
				self.close()

	def write(self):
		self._write()

	def close(self):
		print("closing connection to", self.addr)
		try:
			self.selector.unregister(self.sock)
		except Exception as e:
			print(f"error: selector.unregister() exception for ", f"{self.addr}:{repr(e)}")
		try:
			self.sock.close()
			self.FileHandler.close()
#			if (self.file):
#				self.file.close()
		except OSError as e:
			print(f"error: socket.close() exception for ", f"{self.addr}: {repr(e)}")
		finally:
			# Delete reference to socket object for garbage collection"
			self.sock = None
