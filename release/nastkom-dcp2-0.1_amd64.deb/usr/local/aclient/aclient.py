#!/usr/bin/env python3
import shutil
import os
import socket
import selectors
import types
import traceback
import json
import time

import libclient

def getserial():
	# Extract serial from cpuinfo file
	cpuserial = "0000000000000000"
	try:
		f = open('/proc/cpuinfo','r')
		for line in f:
			if line[0:6]=='Serial':
				cpuserial = line[10:26]
		f.close()
	except:
		#cpuserial = "ERROR000000000"
		cpuserial = "0000000000000000"
	return cpuserial

def check_internet(host, port):
	try:
		s= socket.create_connection((host, port), 2)
		s.close()
		return True
	except:
		pass
	return False

def start_connections(host, port, src, dst, sd_dst, files, serial):
	conn_id = 0
	addr = (host, port)
	for file in files:
		conn_id = conn_id + 1
		#print("starting connection", conn_id, "to", addr, "with" , file)
		sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		sock.setblocking(False)
		""" # see cat /proc/sys/net/ipv4/tcp_syn_retries
		# value 5 means approx 120 seconds to raise exception for sock.connect
		# can use socket.settimeout() to reduce timeout of connection
		#               sock.settimeout(10)
		# but it cause another blocking mode  than setblocking()

		# scok.connect_ex return a value instead of raising exception
		# (but in case 'host not found' it can still raise exception)

		# the socket in nonblocking mode, so tre result of connection you will get
		# after select inidcates socket as writable. Use getsockopt to read the SO_ERROR
		# option at level SOL_SOCKET to determine whether connect() completed succesfully
		# (SO_ERROR is zero) or not (SO_ERROR is one of usual codes)
		# error codes listed int /usr/include/asm-generric/errno.h"""
		sock.connect_ex(addr)
		events = selectors.EVENT_READ | selectors.EVENT_WRITE
		message = libclient.Message(sel, sock, addr, src, dst, sd_dst, file, serial )
		sel.register(sock, events, data=message)

def create_directory(folder):
	try:
		os.mkdir(folder)
		print("Directory ", folder, " Created")
	except:
		print("Directory ", folder, " creation error")
		pass


###             ###
###     MAIN    ###
###             ###
conf_file = "/usr/share/dcp-conf/dcp.conf"
src_folder = "data"
dst_folder = "archive"

sel = selectors.DefaultSelector()

""" create working directories on local disk eMMC"""
#src = os.path.expanduser(os.path.join('~', src_folder))
src = os.path.join('/usr/local/', src_folder)
#dst = os.path.expanduser(os.path.join('~', dst_folder))
dst = os.path.join('/usr/local/', dst_folder)
create_directory(src)
create_directory(dst)

""" create working directories on external drive SD"""
sd_src = os.path.join('/media/sd', src_folder)
sd_dst = os.path.join('/media/sd', dst_folder)
create_directory(sd_src)
create_directory(sd_dst)

serial_str = getserial()
serial = int(serial_str,16).to_bytes(8, 'little')

while True:
	try:
		with open(conf_file, "r") as json_file:
			conf = json.load(json_file)
	except Exception:
		print("dcp.conf file Error")
		shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
		time.sleep(5)
		continue

	if "server_ip" not in conf  or "server_port" not in conf:
		print("ServerIP or serverPort not set")
		shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
		time.sleep(5)
		continue

	HOST = conf["server_ip"]
	PORT = int(conf["server_port"])

	if len(HOST) < 3 or PORT < 80 or PORT  > 65535:
		print("ServerIP or serverPort are bad")
		shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
		time.sleep(5)
		continue

	dfiles =  os.listdir(src)
	files = []
	for file in dfiles:
		size = os.path.getsize(os.path.join(src, file))
		if size != 0:
			files.append(file)

	if check_internet(HOST, PORT) == True:
		if len(files):
			#print("There are ", len(files), " files to send")
			files = files[:10]
			start_connections(HOST, PORT, src, dst, sd_dst, files, serial)

			while True:
				events = sel.select(timeout=1)
				for key, mask in events:
					message = key.data
					try:
						message.process_events(mask)
					except Exception:
						message.close()
				# Check for a socket being monitored to continue.
				if not sel.get_map():
					break
		else:
			print("No files to send")
			time.sleep(30)
	else:
		print("No internet connection")
		time.sleep(30)
