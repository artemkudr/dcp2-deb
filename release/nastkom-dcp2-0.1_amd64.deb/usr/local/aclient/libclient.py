import os
import sys
import selectors
import io
#import struct
#import binascii
import json
import struct
from datetime import datetime
from shutil import make_archive

MIN_BYTES_TO_SEND = 16383
MIN_PACKAGE_LEN = 12

class Message:
	def __init__(self, selector, sock, addr, src, dst, sd_dst, file_name, serial):
		self.selector = selector
		self.sock = sock
		self.addr = addr
		self.src = src
		self.dst = dst
		self.sd_dst = sd_dst
		self.file_name = file_name
		self._recv_buffer = b""
		self._send_buffer = b""
		self.request = None
		self.response_received = False
		self.poll_time = None
		self.poll_now = False
		self.hfile = None
		self.serial = serial
#		self.package_len = 0
#		self.content_type = 0
#		self.file = None
#		self.imei = ""

	def _set_selector_events_mask(self, mode):
		"""Set selector to listen for events : mode is 'r', 'w' or 'rw'."""
		if mode == "r":
			events = selectors.EVENT_READ
		elif mode == "w":
			events = selectors.EVENT_WRITE
		elif mode == "rw":
			events = selectors.EVENT_READ | selectors.EVENT_WRITE
		else:
			raise ValueError(f"Invalid events mask mode {repr(mode)}.")
		self.selector.modify(self.sock, events, data = self)


	def _read(self):
		try:
			data = self.sock.recv(4096)
		except BlockingIOError:
			# Resource temporarily unawailable (errno EWOULDBLOCK)
			pass
		else:
			if data:
				self._recv_buffer += data
			else:
				raise RuntimeError("Peer ", self.addr, " closed")

	def _write(self):
		if self._send_buffer:
			print("sending ", repr(self._send_buffer[:16]), " to ", self.addr)
			try:
				sent = self.sock.send(self._send_buffer)
			except BlockingIOError:
				pass
			else:
				self._set_selector_events_mask("r")
		elif self.hfile == None:
			print("Read header of", self.file_name)
			self.hfile = open(os.path.join(self.src, self.file_name), 'r')
			answer = bytearray()
			answer.extend(b'\xFF')
			answer.extend(b'\x24')
			c_name = self.file_name.split('.')
			answer.extend(int(c_name[0]).to_bytes(8,'little'))
			answer.extend(self.serial)
			self._send_buffer = answer
			print(answer)
			#self._send_buffer[2:10] = struct.pack('<Q',int(self.file_name))
			self._set_selector_events_mask("w")

	def copy_file_to_archive(self):
		utc = datetime.utcnow()
		base_name = os.path.join(self.dst, self.file_name+utc.strftime("_%y%m%d_%H%M%S") )
		try:
			make_archive(base_name, 'zip', self.src, self.file_name)
			sd_base_name = os.path.join(self.sd_dst, self.file_name+utc.strftime("_%y%m%d_%H%M%S") )
			make_archive(sd_base_name, 'zip', self.src, self.file_name)
		except:
			pass
#		os.remove(os.path.join(self.src, self.file_name))
		open(os.path.join(self.src, self.file_name), 'w').close()

	def process_line(self):
#		print("	readLine")
		line = self.hfile.readline()
		if line!='':
			linekv = line.split(':')
			if len(linekv) == 2:
				if linekv[0] == "data":
					package_ba = bytearray.fromhex(linekv[1])
					if ( package_ba[0] ==  0x5B  and package_ba[-1] == 0x5D ):
						package_len = len(package_ba)
#						print("package_len=", package_len)
						if package_len < MIN_PACKAGE_LEN:
							return -1
						package_len_calc = 2
						while package_len_calc < package_len-1 :
#							print ("packet_type=",  package_ba[package_len_calc])
							if  package_ba[package_len_calc] != 0x01 and  package_ba[package_len_calc] != 0x03 and package_ba[package_len_calc] != 0x04:
								print("packet_type_error")
								return -1
							package_len_calc += struct.unpack('<H', package_ba[package_len_calc+1:package_len_calc+3])[0]+ 8
#							print ("package_len_calc=", package_len_calc)
						if package_len_calc != package_len-1:
							print("len error")
							return -1

						if len(self._send_buffer) > 0 :
							self._send_buffer[-1:-1] = package_ba[2:]
							del(self._send_buffer[-1])
						else:
							self._send_buffer = package_ba

						if (len(self._send_buffer) > MIN_BYTES_TO_SEND ) :
							self._set_selector_events_mask("w")
							return 0
			return -1
			#self.process_line()
		else:
			print("EOF ", self.file_name)
			# TODO
			# if something in buffer -> comlete it and send
			#... 
			if len(self._send_buffer):
				self._set_selector_events_mask("w")
				return 0

			self.close()
			self.copy_file_to_archive()
			return 0


	#def _init_recv_process(self):
	#	self.package_len = 0
	#	self.parcel_num = 0
	#	self.content_type = 0

	def process_events(self, mask):
		if mask & selectors.EVENT_READ:
			self.read();
		if mask & selectors.EVENT_WRITE:
			self.write();

	def read(self):
		self._read()
		if len(self._recv_buffer) > 2:
			if self._recv_buffer[0] == 0x7B and self._recv_buffer[1] == 0x04:
				if len(self._recv_buffer) == 9:
					print("Header Ack received")
					self._recv_buffer = self._recv_buffer[9:]
					del(self._send_buffer[:])
					while True:
						if self.process_line()==0:
							break
			elif self._recv_buffer[0] == 0x7B and self._recv_buffer[1] == 0x00:
				if len(self._recv_buffer) == 4:
					print("Data Ack received")
					self._recv_buffer = self._recv_buffer[4:]
					del(self._send_buffer[:])
					while True:
						if self.process_line() == 0:
							break
#			else
#				self.close()

	def write(self):
		self._write()

	def close(self):
		print("closing connection to", self.addr)
		try:
			self.selector.unregister(self.sock)
		except Exception as e:
			print(f"error: selector.unregister() exception for ", f"{self.addr}:{repr(e)}")
		try:
			self.sock.close()
		except OSError as e:
			print(f"error: socket.close() exception for ", f"{self.addr}: {repr(e)}")
		try:
			self.hfile.close()
		except Exception as e:
#			print("error: self.hfile.close() exception")
			pass

		finally:
			# Delete reference to socket object for garbage collection"
			self.sock = None
