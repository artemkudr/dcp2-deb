#!/bin/bash
systemctl stop gpsget.service
systemctl stop wifimode.service
apt-get update
apt-get install nastkom-dcp2
