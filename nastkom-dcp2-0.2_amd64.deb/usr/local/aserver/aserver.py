#!/usr/bin/python3
import shutil
import socket
import selectors
import types
import traceback
import libserver
import json


#def_host = "77.242.3.226"
#def_port = 87

###             ###
###     MAIN    ###
###             ###

def set_keepalive_linux(sock, after_idle_sec=60, interval_sec=60, max_fails=10):
	"""Set TCP keepalive on an open socket.
	It activates after after_idle_sec of idleness,
	then sends a keepalive ping once every interval_sec,
	and closes the connection after max_fails failed ping ()
	"""
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, after_idle_sec)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval_sec)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, max_fails)



def errorExit():
	shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
	time.sleep(5)
	exit()

conf_file = "/usr/share/dcp-conf/dcp.conf"
try:
	with open(conf_file, "r") as json_file:
		conf = json.load(json_file)
		if "local_ip" not in conf  or "local_port" not in conf:
			print("ServerIP or serverPort not set")
			errorExit()

		HOST = conf["local_ip"]
		PORT = int(conf["local_port"])
		if len(HOST) < 3 or PORT < 80 or PORT  > 65535:
			print("ServerIP or serverPort are bad")
			errorExit()
			#HOST = def_host
			#PORT = def_port
except Exception:
	print("dcp.conf file Error")
	errorExit()
	#HOST = def_host
	#PORT = def_port

sel = selectors.DefaultSelector()
lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Avoid bind() exception: OSError: [Errno 48] Address already in use
lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

lsock.bind((HOST,PORT))
lsock.listen()

# TCP Keepalive Options
#lsock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
#lsock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, 1)
#lsock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, 3)
#lsock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, 5)
set_keepalive_linux(lsock, after_idle_sec=15, interval_sec=3, max_fails=5)

print('aserver listening on ', (HOST,PORT))
lsock.setblocking(False)
sel.register(lsock, selectors.EVENT_READ, data=None)


def accept_wrapper(sock):
	conn, addr = sock.accept()
	print('aserver accepted connection from ', addr)
	conn.setblocking(False)
	message = libserver.Message(sel, conn, addr)
	sel.register(conn, selectors.EVENT_READ, data=message)

while True:
	events = sel.select(timeout = None )
	for key, mask in events:
		if key.data is None:
			accept_wrapper(key.fileobj)
		else:
			message = key.data
			try:
				message.process_events(mask)
			except Exception:
				#print('aserver main: error: exception for', f'{message.addr}\n{traceback.format_exc()}')
				message.close()


