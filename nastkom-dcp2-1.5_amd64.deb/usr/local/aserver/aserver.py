#!/usr/bin/python3
import shutil
import socket
import selectors
import types
import traceback
import libserver
import json
import time
from threading import Thread
from datetime import datetime

def set_keepalive_linux(sock, after_idle_sec=60, interval_sec=60, max_fails=10):
	"""Set TCP keepalive on an open socket.
	It activates after after_idle_sec of idleness,
	then sends a keepalive ping once every interval_sec,
	and closes the connection after max_fails failed ping ()
	"""
	sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPIDLE, after_idle_sec)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPINTVL, interval_sec)
	sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_KEEPCNT, max_fails)

def errorExit():
#	shutil.copyfile("/usr/share/dcp-conf/dcp.conf.def", "/usr/share/dcp-conf/dcp.conf")
	time.sleep(5)
	exit()

def proc(ids, ip, port):
	sel = selectors.DefaultSelector()
	lsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

	# Avoid bind() exception: OSError: [Errno 48] Address already in use
	lsock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

	lsock.bind((ip, port))
	lsock.listen()

	# TCP Keepalive Options
	set_keepalive_linux(lsock, after_idle_sec = 15, interval_sec = 3, max_fails = 5)

	print('aserver listening on ', (ip, port))
	lsock.setblocking(False)
	sel.register(lsock, selectors.EVENT_READ, data = None)


	def accept_wrapper(sock):
		conn, addr = sock.accept()
		print('aserver accepted connection from ', addr)
		conn.setblocking(False)
		print(ids)
		message = libserver.Message(sel, conn, addr, ids)
		sel.register(conn, selectors.EVENT_READ, data = message)

	while True:
		events = sel.select(timeout = 5)
		for key, mask in events:
			if key.data is None:
				accept_wrapper(key.fileobj)
			else:
				message = key.data
				try:
					message.process_events(mask)
				except Exception:
					#print('aserver main: error: exception for', f'{message.addr}\n{traceback.format_exc()}')
					message.close()

if __name__ == "__main__":

	SRC_DIR="/usr/local/dcp-rx/"
	DST_DIR="/usr/local/dcp-tx/"
	utc = datetime.utcnow()
	for proto in ["22","23","25"]:
		files = os.listdir(SRC_DIR + proto)
		for f in files:
			shutil.move( os.path.join(SRC_DIR, proto, f),  os.path.join(DST_DIR, proto, f + utc.strftime(".%y%m%d_%H%M%S")))


	conf_file = "/usr/share/dcp-conf/dcp.conf"
	try:
		with open(conf_file, "r") as json_file:
			conf = json.load(json_file)
			ip = '192.168.10.1' #conf["local_ip"]
			port = 55555 #conf["local_port"]
			ids = bytearray()

			if "protocol_id_1"  and "server_port_1" in conf:
				id = int(conf["protocol_id_1"],16)
				#port = int(conf["server_port_1"])
				if (id > 255 or id < 0) or  len(ip) < 3 or port < 80 or port  > 65535:
					print("ProtocolId {id:x} or ServerIP {ip} or serverPort {port} for {idx} cell  are bad".format(id = id, ip = ip, port = port, idx = idx))
				else:
					ids.append(id)

			if "protocol_id_2" and "server_port_2" in conf:
				id = int(conf["protocol_id_2"],16)
				#port = int(conf["server_port_2"])
				if (id > 255 or id < 0) or len(ip) < 3 or port < 80 or port  > 65535:
					print("ProtocolId {id:x} or ServerIP {ip} or serverPort {port} for {idx} cell  are bad".format(id = id, ip = ip, port = port, idx = idx))
				else:
					ids.append(id)

			if "protocol_id_3" and "server_port_3" in conf:
				id = int(conf["protocol_id_3"],16)
				#port = int(conf["server_port_id_3"])
				if (id > 255 or id < 0) or  len(ip) < 3 or port < 80 or port  > 65535:
					print("ProtocolId {id:x} or ServerIP {ip} or serverPort {port} for {idx} cell  are bad".format(id = id, ip = ip, port = port, idx = idx))
				else:
					ids.append(id)

			proc(ids, ip, port)

	except Exception as e:
		print(e)
		#print("dcp.conf file Error")
		errorExit()
