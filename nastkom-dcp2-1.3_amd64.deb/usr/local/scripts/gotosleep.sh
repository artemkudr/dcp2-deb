#! /bin/bash
echo enabled > /sys/devices/platform/soc/40011000.serial/tty/ttySTM0/power/wakeup
echo enabled > /sys/devices/platform/soc/40011000.serial/power/wakeup
echo mem > /sys/power/state 
